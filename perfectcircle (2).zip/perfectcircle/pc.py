'''
Код написан на языке Python с использованием PyGame в редакторе Thonny. 
'''

import pygame
import time
import ctypes
import math
import time

pygame.init()
clock = pygame.time.Clock()
FPS = 300
my_font = pygame.font.SysFont(None, 35)
width_window = 900
height_window = 500
p=100
x=0
y=0
a=0
g=0
t1=False
text_1=my_font.render('слишком близко', False,(255, 0, 0) )
text_2=my_font.render('слишком близко', False,(0, 0, 0) )

screen = pygame.display.set_mode((width_window, height_window))
screen.fill((0,0,0))
pygame.draw.circle(screen,(255, 255, 255), [450, 250], 5)
pygame.display.flip()
running = True



while running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos1 = pygame.mouse.get_pos()
            a1=math.sqrt(((450-pos1[0])**2)+((250-pos1[1])**2))
        if pygame.mouse.get_pressed()[0]:
            pos = pygame.mouse.get_pos()
            a=math.sqrt(((450-pos[0])**2)+((250-pos[1])**2))
            if a<72:
                pygame.draw.circle(screen,(255, 0, 0), pos, 3)
                t1=True
            else:
                pygame.draw.circle(screen,(0, 255, 0), pos, 3)
                t1=False
            if (a1-a>2) or (a-a1>2):
                pygame.draw.circle(screen,(255, 180, 0), pos, 3)
                p-=0.25
                text_3=my_font.render(str(p), False,(255, 180, 0) )
                screen.blit(text_3, (500, 30))
                pygame.draw.rect(screen,(0, 0, 0), [500, 30, 70, 30])
            if (a1-a>5) or (a-a1>5):
                pygame.draw.circle(screen,(255, 0, 0), pos, 3)
                p-=0.5
                text_3=my_font.render(str(p), False,(255, 180, 0) )
                screen.blit(text_3, (500, 30))
            if p<=0:
                p=0
                text_4=my_font.render('Вы проиграли', False,(255, 180, 0) )
                screen.blit(text_4, (500, 50))
                    
            pygame.display.flip()
            if t1:
                screen.blit(text_1, (300, 30))
            else:
                screen.blit(text_2, (300, 30))
    pygame.draw.rect(screen,(0, 0, 0), [500, 30, 70, 30])
    
    pygame.draw.circle(screen,(255, 255, 255), [450, 250], 5)
pygame.quit()